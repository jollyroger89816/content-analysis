# -*- coding: utf-8 -*-
"""
统一SEO分析平台 - Flask主应用
"""
import os
import sys
import json
import logging
from datetime import datetime
from flask import Flask, render_template, request, jsonify, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 导入配置
from config import config
from core.quality_analyzer import QualityAnalyzer
from core.duplicate_analyzer import DuplicateAnalyzer
from core.seo_analyzer import SEOAnalyzer

# 初始化Flask应用
def create_app(config_name='default'):
    """应用工厂函数"""
    app = Flask(__name__)
    app.config.from_object(config[config_name])

    # 启用CORS
    CORS(app, resources={r"/api/*": {"origins": "*"}})

    # 创建必要的目录
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs(app.config.get('REPORT_OUTPUT_DIR', 'reports'), exist_ok=True)
    os.makedirs(os.path.join(app.config['BASE_DIR'], 'logs'), exist_ok=True)

    # 配置日志
    setup_logging(app)

    # 初始化分析器
    try:
        from qianfan import Qianfan
        qianfan_client = Qianfan(
            access_key=app.config.get('QIANFAN_ACCESS_KEY', ''),
            secret_key=app.config.get('QIANFAN_SECRET_KEY', '')
        )
    except Exception as e:
        app.logger.warning(f"无法初始化千帆客户端: {str(e)}")
        qianfan_client = None

    quality_analyzer = QualityAnalyzer(app.config, qianfan_client)
    duplicate_analyzer = DuplicateAnalyzer(app.config)
    seo_analyzer = SEOAnalyzer(app.config, quality_analyzer, duplicate_analyzer)

    # 注册路由
    register_routes(app, quality_analyzer, duplicate_analyzer, seo_analyzer)

    return app


def setup_logging(app):
    """配置日志系统"""
    log_dir = os.path.join(app.config['BASE_DIR'], 'logs')
    os.makedirs(log_dir, exist_ok=True)

    log_file = app.config.get('LOG_FILE', os.path.join(log_dir, 'seo_platform.log'))

    logging.basicConfig(
        level=getattr(logging, app.config.get('LOG_LEVEL', 'INFO')),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler()
        ]
    )


def register_routes(app, quality_analyzer, duplicate_analyzer, seo_analyzer):
    """注册路由"""

    @app.route('/')
    def index():
        """首页"""
        return render_template('dashboard.html')

    @app.route('/api/health', methods=['GET'])
    def health_check():
        """健康检查"""
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.now().isoformat(),
            'version': '1.0.0'
        })

    @app.route('/api/analyze/quality', methods=['POST'])
    def analyze_quality():
        """
        文章质量分析API
        接收URL列表，分析暗示性语言
        """
        try:
            data = request.get_json()
            urls = data.get('urls', [])

            if not urls:
                return jsonify({'error': '请提供URL列表'}), 400

            app.logger.info(f"开始质量分析，共{len(urls)}个URL")

            results = quality_analyzer.batch_analyze(urls)

            return jsonify({
                'success': True,
                'results': results,
                'timestamp': datetime.now().isoformat()
            })

        except Exception as e:
            app.logger.error(f"质量分析失败: {str(e)}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500

    @app.route('/api/analyze/duplicate', methods=['POST'])
    def analyze_duplicate():
        """
        内容重复检测API
        接收URL列表，检测内容重复度
        """
        try:
            data = request.get_json()
            urls = data.get('urls', [])

            if not urls:
                return jsonify({'error': '请提供URL列表'}), 400

            if len(urls) < 2:
                return jsonify({'error': '至少需要2个URL才能进行重复度分析'}), 400

            app.logger.info(f"开始重复度分析，共{len(urls)}个URL")

            results = duplicate_analyzer.batch_analyze(urls)

            return jsonify({
                'success': True,
                'results': results,
                'timestamp': datetime.now().isoformat()
            })

        except Exception as e:
            app.logger.error(f"重复度分析失败: {str(e)}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500

    @app.route('/api/analyze/seo', methods=['POST'])
    def analyze_seo():
        """
        SEO综合分析API
        整合质量和重复度分析
        """
        try:
            data = request.get_json()
            urls = data.get('urls', [])

            if not urls:
                return jsonify({'error': '请提供URL列表'}), 400

            app.logger.info(f"开始SEO综合分析，共{len(urls)}个URL")

            # 执行综合分析
            results = seo_analyzer.batch_analyze(urls)

            return jsonify({
                'success': True,
                'results': results,
                'timestamp': datetime.now().isoformat()
            })

        except Exception as e:
            app.logger.error(f"SEO综合分析失败: {str(e)}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500

    @app.route('/api/analyze/comprehensive', methods=['POST'])
    def analyze_comprehensive():
        """
        综合分析API - 支持自定义分析类型
        """
        try:
            data = request.get_json()
            urls = data.get('urls', [])
            analysis_types = data.get('types', ['quality', 'duplicate', 'seo'])

            if not urls:
                return jsonify({'error': '请提供URL列表'}), 400

            app.logger.info(f"开始综合分析，类型: {analysis_types}, URL数量: {len(urls)}")

            results = {}

            # 执行请求的分析类型
            if 'quality' in analysis_types:
                app.logger.info("执行质量分析...")
                quality_results = quality_analyzer.batch_analyze(urls)
                results['quality'] = quality_results

            if 'duplicate' in analysis_types and len(urls) >= 2:
                app.logger.info("执行重复度分析...")
                duplicate_results = duplicate_analyzer.batch_analyze(urls)
                results['duplicate'] = duplicate_results

            if 'seo' in analysis_types:
                app.logger.info("执行SEO综合分析...")
                # 如果已经执行了单独分析，使用结果；否则执行综合分析
                quality_data = results.get('quality')
                duplicate_data = results.get('duplicate')

                seo_results = seo_analyzer.batch_analyze(urls, quality_data, duplicate_data)
                results['seo'] = seo_results

            return jsonify({
                'success': True,
                'results': results,
                'timestamp': datetime.now().isoformat()
            })

        except Exception as e:
            app.logger.error(f"综合分析失败: {str(e)}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500

    @app.route('/api/dashboard/stats', methods=['GET'])
    def dashboard_stats():
        """
        获取仪表板统计数据
        """
        try:
            # 这里可以从数据库或缓存中获取历史统计数据
            # 暂时返回示例数据
            stats = {
                'total_analyses': 0,
                'pending_tasks': 0,
                'completed_today': 0,
                'average_score': 0
            }

            return jsonify({
                'success': True,
                'stats': stats
            })

        except Exception as e:
            app.logger.error(f"获取统计数据失败: {str(e)}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500

    @app.errorhandler(404)
    def not_found(error):
        """404错误处理"""
        return jsonify({'error': '请求的资源不存在'}), 404

    @app.errorhandler(500)
    def internal_error(error):
        """500错误处理"""
        return jsonify({'error': '服务器内部错误'}), 500


# 创建应用实例
app = create_app()

if __name__ == '__main__':
    # 开发环境运行
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True
    )
