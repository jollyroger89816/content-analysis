# -*- coding: utf-8 -*-
"""配置模块初始化"""
from .settings import config, Config

__all__ = ['config', 'Config']
